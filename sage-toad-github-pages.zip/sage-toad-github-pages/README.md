# 🐸 Sage Toad Mode — GitHub Pages Dashboard

A static, phone-friendly dashboard for drafting and exporting Sage Toad training tasks. **Does not** run Python, connect via SSH, control an agent or store tasks persistently. Keep all SSH keys, credentials and Ollama endpoints private.

## One-time GitHub Pages setup

1. Create an empty **public** repo named `Sage-Toad-Mode` on GitHub. (A public repository is necessary for Pages on GitHub Free.)
2. Upload **all files**, including `.github/workflows/pages.yml`, using GitHub website or git.
3. In repo **Settings → Pages → Build and deployment**, choose **GitHub Actions**. The bundled workflow publishes on pushes to `main`. Run it from Actions if necessary.
4. See the URL displayed by the workflow, typically `https://YOUR_USERNAME.github.io/Sage-Toad-Mode/`.

GitHub Pages hosting is free for public repositories under GitHub Free, subject to GitHub's usage limits and policies. GitHub Actions also has limits; this static site typically needs very little.

## Run actual engine separately

For Python/Docker/Ollama runtime use the `sage_toad_mode_package.zip` distributed separately. The dashboard's command is a convenience, not a remote terminal. Do not expose privileged Docker APIs to a public static page.
